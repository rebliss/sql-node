<nav class="sidebar">
  <div class="sidebar-header">
    <a href="#" class="sidebar-brand">
      Noble<span>UI</span>
    </a>
    <div class="sidebar-toggler not-active">
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>
  <div class="sidebar-body">
    <ul class="nav">
      <li class="nav-item nav-category">Main</li>
      <li class="nav-item">
        <a href="{{url('/dashboard')}}" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Dashboard</span>
        </a>
      </li>
      <li class="nav-item nav-category">ORDER</li>
      <li class="nav-item">
        <a href="order-list" class="nav-link">
          <i class="link-icon" data-feather="message-square"></i>
          <span class="link-title">Order List</span>
        </a>
      </li>
    </ul>
  </div>
</nav>
 @if(session()->has('update'))
            <div class="toastUpdate" >
            </div>
            @endif
<nav class="settings-sidebar">
  <div class="sidebar-body">

    <h6 class="text-muted mb-2">Sidebar:</h6>
    <div class="mb-3 pb-3 border-bottom">
      <div class="form-check form-check-inline">
        <input type="radio" class="form-check-input" name="sidebarThemeSettings" id="sidebarLight" value="sidebar-light" checked>
        <label class="form-check-label" for="sidebarLight">
          Light
        </label>
      </div>
      <div class="form-check form-check-inline">
        <input type="radio" class="form-check-input" name="sidebarThemeSettings" id="sidebarDark" value="sidebar-dark">
        <label class="form-check-label" for="sidebarDark">
          Dark
        </label>
      </div>
    </div>
    <div class="theme-wrapper">
      <h6 class="text-muted mb-2">Light Theme:</h6>
      <a class="theme-item active" href="https://www.nobleui.com/html/template/demo1/dashboard.html">
        <img src="../assets/images/screenshots/light.jpg" alt="light theme">
      </a>
      <h6 class="text-muted mb-2">Dark Theme:</h6>
      <a class="theme-item" href="https://www.nobleui.com/html/template/demo2/dashboard.html">
        <img src="../assets/images/screenshots/dark.jpg" alt="light theme">
      </a>
    </div>
  </div>
</nav>
<nav class="navbar">
  <a href="#" class="sidebar-toggler">
    <i data-feather="menu"></i>
  </a>
  <div class="navbar-content">
    <form class="search-form">
      <div class="input-group">
        <div class="input-group-text">
          <i data-feather="search"></i>
        </div>

      </div>
    </form>

    <ul class="navbar-nav">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img class="wd-30 ht-30 rounded-circle" src="../assets/images/faces/face1.jpg" alt="profile">
        </a>
        <div class="dropdown-menu p-0" aria-labelledby="profileDropdown">
          <div class="d-flex flex-column align-items-center border-bottom px-5 py-3">
            <div class="mb-3">
              <img class="wd-80 ht-80 rounded-circle" src="../assets/images/faces/face1.jpg" alt="">
            </div>
<?php $i=1;?>
             @foreach($user as $list)

              @if($i==1)
            <div class="text-center">
              <p class="tx-16 fw-bolder">{{$list['name']}}</p>
              <p class="tx-12 text-muted">{{$list['email']}}</p>
            </div>
            @endif
 <?php $i=2;?>
            @endforeach
          </div>
          <ul class="list-unstyled p-1">

            <li class="dropdown-item py-2">
              <a type="button" data-bs-toggle="modal" data-bs-target="#profile" class="text-body ms-0">
                <i class="me-2 icon-md" data-feather="edit"></i>
                <span>Edit Profile</span>
              </a>
            </li>



            <li class="dropdown-item py-2">
              <a href="{{url('logout')}}" class="text-body ms-0">
                <i class="me-2 icon-md" data-feather="log-out"></i>
                <span>Log Out</span>
              </a>
            </li>
          </ul>
        </div>
      </li>
    </ul>
  </div>
</nav>

<div class="modal fade" id="profile" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="btn-close"></button>
              </div>
              <form id="form-submit" action="{{url('user/update')}}" method="post">
                @csrf
                <?php $i=1; ?>
                @foreach ($user as $item)
                @if($i==1)
                <div class="modal-body">
                  <input type="hidden" class="form-control" name="id" value="{{$item['id']}}"><br>

                  User Name<span class="text-danger">  *</span>
                  <input type="text" class="form-control" name="name" value="{{$item['name']}}" placeholder="Enter User Name" required><br>
                  Email<span class="text-danger">  *</span>
                  <input type="text" class="form-control" name="email" value="{{$item['email']}}" placeholder="Enter Email" required><br>
                                  @endif
                  <?php $i=2; ?>
                  @endforeach
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
          </div>
        </div>