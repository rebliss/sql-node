<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AuthController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.login');


});
Route::get('/register', function () {
    return view('auth.register');

});
Route::get('/dashboard',[AuthController::class,'index']);
Route::get('/order-list',[OrderController::class,'index']);
Route::get('/order-delete/{id}',[OrderController::class,'orderDelete']);
Route::post('/order-insert',[OrderController::class,'orderInsert']);
Route::get('/order-get/{id}',[OrderController::class,'orderget']);
Route::post('/order-update',[OrderController::class,'orderUpdate']);

Route::post('/login',[AuthController::class,'login']);
Route::post('/register/user',[AuthController::class,'RegisterUser']);


Route::get('/logout',[AuthController::class,'logout']);
Route::post('/user/update',[AuthController::class,'userUpdate']);
