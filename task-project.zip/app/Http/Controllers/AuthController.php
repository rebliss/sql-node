<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Session;
use Validator;
class AuthController extends Controller
{
    public function __construct()
    {
        $token = session()->get('api_token');
        if (!$token) {
            return redirect('/');
        }
    }
    public function index(){
        $token = session()->get('api_token');
        if (!$token) {
            return redirect('/');
        }
        $token = session()->get('api_token');
        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept' => 'application/json',
        ];
        $client = new Client();
        $response = $client->get('localhost:3000/order/total/order/all', ['headers' => $headers]); // Replace with the actual API URL
        $all = json_decode($response->getBody(), true);
        $response = $client->get('localhost:3000/order/total/order/today', ['headers' => $headers]); // Replace with the actual API URL
        $today = json_decode($response->getBody(), true);
        $response = $client->get('localhost:3000/order/total/order/month', ['headers' => $headers]); // Replace with the actual API URL
        $month = json_decode($response->getBody(), true);
        $response = $client->get('localhost:3000/order/', ['headers' => $headers]); // Replace with the actual API URL
        $recent = json_decode($response->getBody(), true);
        $userdata = session()->get('userData');
        return view('dashboard',['all'=>$all,'today'=>$today,'month'=>$month,'recent'=>$recent,'user'=>$userdata]);
    }

    public function RegisterUser(Request $request){
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'password' => 'required',
        ]);
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ];
        $client = new Client();
        $response = $client->post('localhost:3000/user/register', [
            'headers' => $headers,
            'json' => $request->all(),
        ]); // Replace with the actual API URL
         $data = json_decode($response->getBody(), true);

         if($data['data']=='409'){
        return redirect()->back()->with('error','Email Already Exist');
         }
         else{
        return redirect()->back()->with('success','User Register Successfully');

         }

    }
    public function login(Request $request){
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
        $client = new Client();
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ];
        $response = $client->post('localhost:3000/user/login', [
            'headers' => $headers,
            'json' => $request->all(),
        ]);
        $data = json_decode($response->getBody(), true);
        // Check if login was successful
        if($response->getStatusCode() === 200 && isset($data['token'])) {
            // Store the token in session or any other suitable storage mechanism
            session(['api_token' => $data['token']]);
            session(array('userData' => $data));
            return redirect('/dashboard');
        }
        else {
            return redirect()->back()->with('error','Please Try Again !! Invalid Credetials');
        }
    }
    public function userUpdate(Request $request){
        $token = session()->get('api_token');
        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ];
        $client = new Client();
        $response = $client->put('localhost:3000/user/' . $request->id, [
            'headers' => $headers,
            'json' => $request->all(),
        ]); // Replace with the actual API URL
        $data = json_decode($response->getBody(), true);
        return redirect('dashboard')->with('update','Order Updated');
    }
    public function logout(){
        session::flush();
        return redirect('/');
    }
}
