<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
class OrderController extends Controller
{
     public function __construct()
    {
        $token = session()->get('api_token');
        if (!$token) {
            return redirect('/');
        }
    }
    function index(){
         $token = session()->get('api_token');
        if (!$token) {
            return redirect('/');
        }
        $token = session()->get('api_token');
        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept' => 'application/json',
        ];
        $client = new Client();
        $response = $client->get('localhost:3000/order/', ['headers' => $headers]); // Replace with the actual API URL
        $data = json_decode($response->getBody(), true);
        $userdata = session()->get('userData');

        return view('order-list',['orders'=>$data,'user'=>$userdata]);
    }
    function orderDelete($id){
        $token = session()->get('api_token');
        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept' => 'application/json',
        ];
        $client = new Client();
        $response = $client->delete('localhost:3000/order/' . $id, ['headers' => $headers]); // Replace with the actual API URL
        $data = json_decode($response->getBody(), true);
        return response()->json($data);
    }

    function orderInsert(Request $request){

        $token = session()->get('api_token');
        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ];

        $client = new Client();

        $response = $client->post('localhost:3000/order', [
            'headers' => $headers,
            'json' => $request->all(),
        ]); // Replace with the actual API URL

        return redirect('order-list')->with('create','Order Created Successfully');
    }

    function orderget($id){
       $token = session()->get('api_token');
        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept' => 'application/json',
        ];
        $client = new Client();
        $response = $client->get('localhost:3000/order/' . $id, ['headers' => $headers]); // Replace with the actual API URL
        $data = json_decode($response->getBody(), true);
        $data = $data['orders'];
        return $data;
    }

    public function orderUpdate(Request $request){

          $token = session()->get('api_token');
        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ];

        $client = new Client();

        $response = $client->put('localhost:3000/order/' . $request->id, [
            'headers' => $headers,
            'json' => $request->all(),
        ]); // Replace with the actual API URL

        $data = json_decode($response->getBody(), true);
        return redirect('order-list')->with('update','Order Updated');
    }
}
