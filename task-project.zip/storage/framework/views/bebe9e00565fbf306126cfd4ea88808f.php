   <style>
    .error{
      color:red
    }
  </style>
  <?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="page-wrapper" >
    <?php echo $__env->make('common.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-content" >
      <div class="row" id="bodyid">
        <div class="col-md-12 grid-margin stretch-card">
          <div class="card ">
            <?php if(session()->has('update')): ?>
            <div class="toastUpdate" >
            </div>
            <?php endif; ?>
            <?php if(session()->has('create')): ?>
            <div class="toastCreate" >
            </div>
            <?php endif; ?>
            <div class="card-body">
              <h6 class="card-title">ORDER LIST</h6>
              <div style="text-align: right">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                  New Order
                </button>
              </div>
              <div class="table-responsive" id="myid">
                <table id="dataTableExample" class="table">
                  <thead>
                    <tr>
                      <th>S.n</th>
                      <th>Customer Name</th>
                      <th>Item Name</th>

                      <th>Order Number</th>
                      <th>total</th>
                      <th>Order Date</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody id="krishna">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($item['customer_name']); ?></td>
                      <td><?php echo e($item['item_name']); ?></td>
                      <td><?php echo e($item['order_no']); ?></td>
                      <td><?php echo e($item['total']); ?></td>
                      <td><?php echo e($item['order_date']); ?></td>
                      <td><?php echo e($item['status']); ?></td>
                      <td><a  onclick="updateData(<?php echo e($item['id']); ?>)" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editmodal">Edit</a> <a class="btn btn-danger" type="button"onclick="deleteData(<?php echo e($item['id']); ?>)">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">ADD New Order</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="btn-close"></button>
              </div>
              <form id="form-submit" action="<?php echo e(url('order-insert')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                  Customer Name<span class="text-danger">  *</span>
                  <input type="text" class="form-control" name="customer_name" placeholder="Enter Customer Name" required><br>
                  Item Name<span class="text-danger">  *</span>
                  <input type="text" class="form-control" name="item_name" placeholder="Enter Item Name" required><br>
                  total<span class="text-danger"> *</span>
                  <input type="text" class="form-control" name="total" placeholder="Enter total " required><br>
                  Status<span class="text-danger"> *</span>
                  <select class="form-control"  name="status" required>
                    <option value="Completed">Completed</option>
                    <option value="Shipped">Shipped</option>
                    <option value="Cancelled">Cancelled</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Order</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="btn-close"></button>
              </div>
              <form id="form-submit" action="<?php echo e(url('order-update')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                  <input type="hidden" id="update-id"  class="form-control" name="id" placeholder="Enter Customer Name" required><br>
                  Customer Name<span class="text-danger">  *</span>
                  <input type="text" id="customer-name" class="form-control" name="customer_name" placeholder="Enter Customer Name" required><br>
                  Item Name<span class="text-danger">  *</span>
                  <input type="text" id="item-name" class="form-control" name="item_name" placeholder="Enter Item Name" required><br>

                  total<span class="text-danger"> *</span>
                  <input type="text" id="total" class="form-control" name="total" placeholder="Enter total " required><br>
                  Status<span class="text-danger"> *</span>
                  <select class="form-control" id="status"  name="status" required>
                    <option value="Completed">Completed</option>
                    <option value="Shipped">Shipped</option>
                    <option value="Cancelled">Cancelled</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
<!-- core:js -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
  function deleteData(id){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.ajax({
          url:"<?php echo e(url('/order-delete')); ?>/"+id,
          method:"get",
          success:function(res){
            // $( "#bodyid").load(window.location.href + " #bodyid" )
            location.reload();
          }
        });
        Swal.fire(
        'Deleted!',
        'Your file has been deleted.',
        'success'
        )
      }
    })
  }
</script>
<script>
  function updateData(id){
    $.ajax({
      url:"<?php echo e(url('/order-get')); ?>/"+id,
      method:"get",
      success:function(employeeData){
        if (employeeData) {
          var html = '';
          var serial_no = 1;
          if (employeeData.length > 0) {
            for (var count = 0; count < employeeData.length; count++) {
              $('#customer-name').val(employeeData[count].customer_name);
              $('#total').val(employeeData[count].total);
              $('#update-id').val(employeeData[count].id);
              $('#item-name').val(employeeData[count].item_name);
              $('#status').val(employeeData[count].status);
            }
          }
          $('#tBody').html(html);
        }
      }
    });
  }
</script>
<script>
  $(document).ready(function() {
    $("#form-submit").validate();
  });
</script>
<script>
  setTimeout(function(){
    document.getElementsByClassName("alert").innerHTML = '';
  }, 3000);
</script>
<?php /**PATH C:\xampp\htdocs\task-project\resources\views/order-list.blade.php ENDPATH**/ ?>