$(function () {
    'use strict';



    if ($(".toastUpdate").length) {
        toastr.success("Success ! Order updated");
    }
    if ($(".toastCreate").length) {
        toastr.success("Success ! Order Created");
    }
});