const bcrypt = require('bcrypt');
const { sign } = require('../config/jwt');
const User = require('../models/user');
const validation = require('../helpers/validations');


const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findByEmail(email);
    if (!user) res.json({ 'data':'401' });
    const match = await bcrypt.compare(password, user.password);
    if (!match) res.json({ 'data': '401' });
    else {
      const token = sign({ id: user.user }); res.json({ 'data': user, token });
    }
  } catch (err) {
    next(err);
  }
};

const register = async (req, res, next) => {
  try {
    const { name ,email } = req.body;
    const password = await bcrypt.hash(req.body.password, 10);
    const user = await User.create(name,email, password);
    if (user == 0) {
      // res.status(400).json({'data':'1', 'message': 'Email Already Exists', 'status': 400 });
      res.send({ 'data': '409', 'message': 'Email Already Exists', 'status': 400 });
    }
    if (user) {
      res.status(201).json({ 'message': 'Recored created', 'status': 201, data: user });
    }
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Invalid email or password' });
    const token = sign({ id: user.id });
    res.json({ token });
  } catch (err) {
    next(err);
  }
};

const UpdateByID = async (req, res, next) => {
  const orders1 = await validation.validate(req.body);
  if (orders1.status == '400') {
    res.send(orders1);
  }
  try {
    const orders = await User.UpdateByID(req.params.id, req.body);
    if (orders == '0') {
      res.status(400).json({ "messages": 'Record not found', 'status': 400 });
    }
    res.status(200).json({ "messages": 'Record Updated', 'status': 200, orders });
  } catch (err) {
    next(err);
  }
};

module.exports = { login, register, UpdateByID }
