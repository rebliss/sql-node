const db = require('../config/database');

const findByEmail = async (email) => {

const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
return rows[0];
};
const create = async (name,email,password) =>{
    const [rows1]= await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if(rows1.length > 0){
       return '0';
    }
    else{
        const [rows] = await db.query('INSERT INTO users (name,email, password) VALUES (?,?, ?)', [name,email, password]);
        return { id: rows.insertId, name,email };
    }

}

const UpdateByID = async (id, data) => {
    const {name, email } = data;
    const [rows1] = await db.query('SELECT * FROM users WHERE id = ?', [id]);
    if (rows1.length > 0) {
        const [data1] = await db.query('UPDATE users SET name = ?, email = ?  WHERE id = ?', [name,email, id]);
        return {name, email};
    }
    else {
        return '0';
    }

}

module.exports = { create, findByEmail, UpdateByID }