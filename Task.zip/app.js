const express = require('express');
const { handle } = require('./middleware/error');
const config = require('./config/config');
const cookieParser = require('cookie-parser');
const app = express();
app.use(express.json());
app.use(cookieParser());

app.use('/user', require('./routes/user'));
app.use('/order', require('./routes/order'));
app.use(handle);

app.listen(config.port, () => {
    console.log(`Server listening on port ${config.port}`);
    });
   
    