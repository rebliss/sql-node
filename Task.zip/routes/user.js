const express = require('express');
const  userlogin = require('../controllers/user');
const router = express.Router();

router.post('/login', [userlogin.login]);
router.post('/register', [userlogin.register]);
router.put('/:id', [userlogin.UpdateByID]);
module.exports = router;